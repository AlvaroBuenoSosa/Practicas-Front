import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, map, Observable, tap } from 'rxjs';
import { Articulo } from '../model/Articulo';

@Injectable({
  providedIn: 'root'
})
export class ArticuloService {
  private apiUrl = 'http://localhost:3000/articulos';

  private articulos = new BehaviorSubject<Articulo[]>([]);

  articulos$ = this.articulos.asObservable();
  contadorArticulos$: Observable<number>;

  constructor(private http: HttpClient) {
    this.http.get<Articulo[]>(this.apiUrl).subscribe(data => {
      this.articulos.next(data);
    });
    this.contadorArticulos$ = this.articulos$.pipe(
      map(articulos => articulos.length)
    );
  }

  getArticulos(): Observable<Articulo[]> {
    return this.articulos$;  
  }

  setArticulos(articulos: Articulo[]) {
    this.articulos.next(articulos);
  }

  getContadorArticulos(): Observable<number> {
    return this.contadorArticulos$;
  }

  crearArticulo(articulo: Articulo): Observable<Articulo> {
    return this.http.post<Articulo>(this.apiUrl, articulo).pipe(
      map(articuloNuevo => {
        const articulosActualizados = [...this.articulos.getValue(), articuloNuevo];
        this.articulos.next(articulosActualizados);
        return articuloNuevo;
      })
    );
  }

  modificarArticulo(articulo: Articulo): Observable<Articulo> {
    return this.http.put<Articulo>(`${this.apiUrl}/${articulo.id}`, articulo).pipe(
      tap((articuloModificado) => {
        const articulosActuales = this.articulos.getValue();
        const i = articulosActuales.findIndex(a => a.id === articulo.id);
        articulosActuales[i] = articuloModificado;
        this.articulos.next(articulosActuales);
      })
    );
  }

  eliminarArticulo(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`).pipe(
      tap(() => {
        const articulosActuales = this.articulos.getValue();
        const articulosModificados = articulosActuales.filter(a => a.id !== id);
        this.articulos.next(articulosModificados);
      })
    );
  }
}
