import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, map, Observable, tap } from 'rxjs';
import { Usuario } from '../model/Usuario';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:3000/users';

  private usuarios = new BehaviorSubject<Usuario[]>([])
  private usuarioSeleccionado = new BehaviorSubject<Usuario | null>(null);

  usuarios$ = this.usuarios.asObservable();
  usuarioSeleccionado$ = this.usuarioSeleccionado.asObservable();
  contadorUsuarios$: Observable<number>;

  constructor(private http: HttpClient) {
    this.http.get<Usuario[]>(this.apiUrl).subscribe(data => {
      this.usuarios.next(data);
    });
    this.contadorUsuarios$ = this.usuarios$.pipe(
      map(usuarios => usuarios.length)
    );
  }

  getUsuarios(): Observable<Usuario[]> {
    return this.usuarios$;
  }

  setUsuarios(usuarios: Usuario[]) {
    this.usuarios.next(usuarios);
  }

  getUsuarioSeleccionado(): Observable<Usuario | null> {
    return this.usuarioSeleccionado$;
  }

  setUsuarioSeleccionado(usuario: Usuario | null): void {
    this.usuarioSeleccionado.next(usuario);
  }

  getContadorUsuarios(): Observable<number> {
    return this.contadorUsuarios$;
  }

  crearUsuario(usuario: Usuario): Observable<Usuario> {
    return this.http.post<Usuario>(this.apiUrl, usuario).pipe(
      map(usuarioNuevo => {
        const usuariosActualizados = [...this.usuarios.getValue(), usuarioNuevo];
        this.usuarios.next(usuariosActualizados);
        return usuarioNuevo;
      })
    );
  }

  modificarUsuario(usuario: Usuario): Observable<Usuario> {
    return this.http.put<Usuario>(`${this.apiUrl}/${usuario.id}`, usuario).pipe(
      tap((usuarioModificado) => {
        const usuariosActuales = this.usuarios.getValue();
        const i = usuariosActuales.findIndex(u => u.id === usuario.id);
        usuariosActuales[i] = usuarioModificado;
        this.usuarios.next(usuariosActuales);
      })
    );
  }

  eliminarUsuario(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`).pipe(
      tap(() => {
        const usuariosActuales = this.usuarios.getValue();
        const usuariosModificados = usuariosActuales.filter(u => u.id !== id);
        this.usuarios.next(usuariosModificados);
      })
    );
  }
}
