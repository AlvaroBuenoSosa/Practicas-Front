export interface Articulo {
    id: number;
    nombre: string;
    precio: number;
    stock: number;
}