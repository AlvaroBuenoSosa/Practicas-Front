import { PedidoArticulo } from "./PedidoArticulo";

export interface Pedido {
    id: number;
    fecha: Date;
    nombre: string;
    articulos: PedidoArticulo[];
}