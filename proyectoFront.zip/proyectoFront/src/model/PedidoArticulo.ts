import { Articulo } from "./Articulo";

export interface PedidoArticulo {
    articulo: Articulo;
    cantidad: number
}