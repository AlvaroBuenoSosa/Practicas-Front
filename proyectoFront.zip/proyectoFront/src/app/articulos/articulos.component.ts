import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ArticuloService } from '../../service/articulo.service';
import { combineLatest, map, Observable, startWith } from 'rxjs';
import { Articulo } from '../../model/Articulo';

@Component({
  selector: 'app-articulos',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './articulos.component.html',
  styleUrl: './articulos.component.css'
})
export class ArticulosComponent {
  private articuloService = inject(ArticuloService);
  articulos$: Observable<Articulo[]>;
  contadorArticulos$: Observable<number>;
  articuloForm: FormGroup;
  filtroForm: FormControl;
  mostrarForm: boolean = false;
  mostrarArticulos: boolean = false;
  articuloModificar: Articulo | null = null;

  constructor(private fb: FormBuilder) {
    this.contadorArticulos$ = this.articuloService.getContadorArticulos();
    this.articuloForm = this.fb.group({
      nombre: ['', Validators.required],
      precio: [0.0, Validators.required],
      stock: [0, Validators.required]
    });
    this.filtroForm = new FormControl('');
    this.articulos$ = combineLatest([
      this.articuloService.getArticulos(),
      this.filtroForm.valueChanges.pipe(startWith(''))
    ]).pipe(
      map(([articulos, filtro]) =>
        articulos.filter(articulo => articulo.nombre.toLowerCase().includes(filtro.toLowerCase()))
      )
    )
  }

  crearArticulo(): void {
    if (this.articuloForm.valid) {
      const articuloNuevo: Articulo = this.articuloForm.value;
      this.articuloService.crearArticulo(articuloNuevo).subscribe(() => {
        this.articuloForm.reset();
      });
    }
  }

  seleccionarArticuloModificar(articulo: Articulo): void {
    this.articuloModificar = articulo;
    this.articuloForm.patchValue(articulo);
    this.mostrarArticulos = false;
    this.mostrarForm = true;
  }

  modificarArticulo(): void {
    if (this.articuloForm.valid && this.articuloModificar) {
      const articuloModificado = { ...this.articuloModificar, ...this.articuloForm.value };
      this.articuloService.modificarArticulo(articuloModificado).subscribe(() => {
        this.articuloForm.reset();
        this.articuloModificar = null;
      });
      this.mostrarForm = false;
      this.mostrarArticulos = true;
    }
  }

  eliminarArticulo(id: number): void {
    this.articuloService.eliminarArticulo(id).subscribe();
  }

  toggleFormulario(): void {
    this.mostrarForm = !this.mostrarForm;
    this.mostrarArticulos = false;
  }

  toggleArticulos(): void {
    this.mostrarArticulos = !this.mostrarArticulos;
    this.mostrarForm = false;
  }
}
