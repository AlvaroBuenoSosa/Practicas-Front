import { Component, inject, OnInit } from '@angular/core';
import { Usuario } from '../../model/Usuario';
import { UserService } from '../../service/user.service';
import { CommonModule } from '@angular/common';
import { combineLatest, map, Observable, startWith } from 'rxjs';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-usuarios',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './usuarios.component.html',
  styleUrl: './usuarios.component.css'
})
export class UsuariosComponent {
  private userService = inject(UserService);
  usuarios$: Observable<Usuario[]>;
  usuarioSeleccionado$: Observable<Usuario | null>;
  contadorUsuarios$: Observable<number>;
  usuarioForm: FormGroup;
  filtroForm: FormControl;
  mostrarForm: boolean = false;
  mostrarUsuarios: boolean = false;
  usuarioModificar: Usuario | null = null;

  constructor(private fb: FormBuilder) {
    this.usuarioSeleccionado$ = this.userService.getUsuarioSeleccionado();
    this.contadorUsuarios$ = this.userService.getContadorUsuarios();
    this.usuarioForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
    this.filtroForm = new FormControl('');
    this.usuarios$ = combineLatest([
      this.userService.getUsuarios(),
      this.filtroForm.valueChanges.pipe(startWith(''))
    ]).pipe(
      map(([usuarios, filtro]) =>
        usuarios.filter(usuario => usuario.username.toLowerCase().includes(filtro.toLowerCase()))
      )
    )
  }

  crearUsuario(): void {
    if (this.usuarioForm.valid) {
      const usuarioNuevo: Usuario = this.usuarioForm.value;
      this.userService.crearUsuario(usuarioNuevo).subscribe(() => {
        this.usuarioForm.reset();
      });
    }
  }

  seleccionarUsuarioModificar(usuario: Usuario): void {
    this.usuarioModificar = usuario;
    this.usuarioForm.patchValue(usuario);
    this.mostrarUsuarios = false;
    this.mostrarForm = true;
  }

  modificarUsuario(): void {
    if (this.usuarioForm.valid && this.usuarioModificar) {
      const usuarioModificado = { ...this.usuarioModificar, ...this.usuarioForm.value };
      this.userService.modificarUsuario(usuarioModificado).subscribe(() => {
        this.usuarioForm.reset();
        this.usuarioModificar = null;
      });
      this.mostrarForm = false;
      this.mostrarUsuarios = true;
    }
  }

  eliminarUsuario(id: number): void {
    this.userService.eliminarUsuario(id).subscribe();
  }

  toggleFormulario(): void {
    this.mostrarForm = !this.mostrarForm;
    this.mostrarUsuarios = false;
  }

  toggleUsuarios(): void {
    this.mostrarUsuarios = !this.mostrarUsuarios;
    this.mostrarForm = false;
  }
}
