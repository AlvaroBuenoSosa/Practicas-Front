import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UsuariosComponent } from './usuarios/usuarios.component';
import { ArticulosComponent } from './articulos/articulos.component';

export const routes: Routes = [
    { 
        path: '', 
        component: DashboardComponent,
        children: [
            { path: 'usuarios', component: UsuariosComponent },
            { path: 'articulos', component: ArticulosComponent }
        ]
    }
];
