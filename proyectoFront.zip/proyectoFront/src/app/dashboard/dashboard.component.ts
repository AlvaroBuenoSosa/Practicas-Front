import { Component, inject, OnInit } from '@angular/core';
import { Usuario } from '../../model/Usuario';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { UserService } from '../../service/user.service';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { ArticuloService } from '../../service/articulo.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterOutlet]
})
export class DashboardComponent {
  userService = inject(UserService);
  articuloService = inject(ArticuloService);
  usuarios$: Observable<Usuario[]>;
  usuarioSeleccionado$: Observable<Usuario | null>;
  contadorUsuarios$: Observable<number>;
  contadorArticulos$: Observable<number>;

  constructor(private router: Router) {
    this.usuarios$ = this.userService.getUsuarios();
    this.usuarioSeleccionado$ = this.userService.getUsuarioSeleccionado();
    this.contadorUsuarios$ = this.userService.getContadorUsuarios();
    this.contadorArticulos$ = this.articuloService.getContadorArticulos();
  }

  seleccionarUsuario(usuario: Usuario) {
    this.userService.setUsuarioSeleccionado(usuario);
  }

  deseleccionarUsuario() {
    this.userService.setUsuarioSeleccionado(null);
  }
}
