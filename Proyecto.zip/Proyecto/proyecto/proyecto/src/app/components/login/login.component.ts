import { Component, OnInit } from '@angular/core';
import { UserService } from '../../shared/services/user-service.service';
import { UsuarioSeleccionadoService } from '../../shared/services/usuario-seleccionado.service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  usuarios: any[] = [];
  selectedUsuario: any;
  contrasena: string = '';

  constructor(
    private usuarioService: UserService,
    private usuarioSeleccionadoService: UsuarioSeleccionadoService,
    private router: Router
  ) {}

  ngOnInit() {
    this.usuarioService.getUsuarios().subscribe(data => this.usuarios = data);
  }

  iniciarSesion() {
    if (this.selectedUsuario && this.selectedUsuario.contrasena === this.contrasena) {
      this.usuarioSeleccionadoService.setUsuario(this.selectedUsuario);
      this.router.navigate(['/dashboard']);
    } else {
      alert('Usuario o contraseña incorrectos');
    }
  }

  mostrarRegistro() {
    this.router.navigate(['/registro']);
  }
}
