import { CommonModule } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { UserService } from "../../shared/services/user-service.service";
import { UsuarioSeleccionadoService } from "../../shared/services/usuario-seleccionado.service";

@Component({
  selector: 'app-usuarios',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './usuarios.component.html',
  styleUrl: './usuarios.component.scss'
})
export class UsuariosComponent implements OnInit {
  usuarios: any[] = [];
  nuevoUsuarioNombre: string = '';
  nuevoUsuarioContrasena: string = '';
  nuevoUsuarioRol: string = 'user';
  modo: 'nuevo' | 'consulta' = 'consulta';
  isAdmin: boolean = false;

  constructor(
    private usuarioService: UserService,
    private usuarioSeleccionadoService: UsuarioSeleccionadoService
  ) {}

  ngOnInit() {
    const usuarioLogueado = this.usuarioSeleccionadoService.getUsuario();
    this.isAdmin = usuarioLogueado?.rol === 'admin';
    this.consultarUsuarios();
  }

  nuevoUsuario() {
    if (this.isAdmin) {
      this.modo = 'nuevo';
    } else {
      alert('No tienes permisos para crear usuarios.');
    }
  }

  consultarUsuarios() {
    this.modo = 'consulta';
    this.usuarioService.getUsuarios().subscribe(data => this.usuarios = data);
  }

  agregarUsuario() {
    if (this.nuevoUsuarioNombre.trim() && this.nuevoUsuarioContrasena.trim() && this.nuevoUsuarioRol) {
      const nuevoUsuario = {
        nombre: this.nuevoUsuarioNombre,
        contrasena: this.nuevoUsuarioContrasena,
        rol: this.nuevoUsuarioRol,
        pedidos: [],
        topArticulos: []
      };
      this.usuarioService.addUsuario(nuevoUsuario).subscribe(() => {
        this.consultarUsuarios();
        this.nuevoUsuarioNombre = '';
        this.nuevoUsuarioContrasena = '';
        this.nuevoUsuarioRol = 'user';
      });
    }
  }
}