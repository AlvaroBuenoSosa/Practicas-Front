import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ArticulosServiceService } from '../../shared/services/articulos-service.service';
import { UsuarioSeleccionadoService } from '../../shared/services/usuario-seleccionado.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-articulos',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './articulos.component.html',
  styleUrl: './articulos.component.scss'
})
export class ArticulosComponent implements OnInit {
  articulos: any[] = [];
  nuevoArticuloNombre: string = '';
  nuevoArticuloDescripcion: string = '';
  nuevoArticuloPrecio: number = 0;
  nuevoArticuloStock: number = 0;
  modo: 'nuevo' | 'consulta' = 'consulta';
  isAdmin: boolean = false;

  constructor(
    private articuloService: ArticulosServiceService,
    private usuarioSeleccionadoService: UsuarioSeleccionadoService
  ) {}

  ngOnInit() {
    const usuarioLogueado = this.usuarioSeleccionadoService.getUsuario();
    this.isAdmin = usuarioLogueado?.rol === 'admin';
    this.articuloService.getArticulos().subscribe(data => this.articulos = data);
  }

  nuevoArticulo() {
    if (this.isAdmin) {
      this.modo = 'nuevo';
    } else {
      alert('No tienes permisos para crear artículos.');
    }
  }

  consultarArticulos() {
    this.modo = 'consulta';
    this.articuloService.getArticulos().subscribe(data => {
      this.articulos = data;
    });
  }

  agregarArticulo() {
    if (this.nuevoArticuloNombre.trim() && this.nuevoArticuloDescripcion.trim() && this.nuevoArticuloPrecio > 0 && this.nuevoArticuloStock >= 0) {
      const nuevoArticulo = {
        nombre: this.nuevoArticuloNombre,
        descripcion: this.nuevoArticuloDescripcion,
        precio: this.nuevoArticuloPrecio,
        stock: this.nuevoArticuloStock
      };
      this.articuloService.addArticulo(nuevoArticulo).subscribe(() => {
        this.consultarArticulos();
        this.nuevoArticuloNombre = '';
        this.nuevoArticuloDescripcion = '';
        this.nuevoArticuloPrecio = 0;
        this.nuevoArticuloStock = 0;
      });
    }
  }
}

