import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { PedidosServiceService } from '../../shared/services/pedidos-service.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ArticulosServiceService } from '../../shared/services/articulos-service.service';
import { UsuarioSeleccionadoService } from '../../shared/services/usuario-seleccionado.service';

@Component({
  selector: 'app-pedidos',
  standalone: true,
  templateUrl: './pedidos.component.html',
  styleUrls: ['./pedidos.component.scss'],
  imports: [CommonModule, FormsModule]
})
export class PedidosComponent implements OnInit {
  pedidos: any[] = [];
  articulos: any[] = [];
  nuevoPedido: any = { articulos: [] };
  articuloSeleccionado: any = null;
  cantidad: number = 0;
  mostrarFormularioNuevoPedido: boolean = false;
  mostrarPedidos: boolean = false;

  constructor(
    private pedidoService: PedidosServiceService,
    private articuloService: ArticulosServiceService,
    private usuarioSeleccionadoService: UsuarioSeleccionadoService,
    private router: Router
  ) {}

  ngOnInit() {
    this.articuloService.getArticulos().subscribe(data => this.articulos = data);
  }

  consultarPedidos() {
    this.pedidoService.getPedidos().subscribe(data => {
      this.pedidos = data;
      this.mostrarPedidos = true;
    });
  }

  agregarPedido() {
    const usuarioLogueado = this.usuarioSeleccionadoService.getUsuario();
    this.nuevoPedido.usuario = usuarioLogueado.nombre;
    this.nuevoPedido.total = this.nuevoPedido.articulos.reduce((sum: any, articulo: any) => sum + (articulo.precio * articulo.cantidad), 0);

    this.pedidoService.addPedido(this.nuevoPedido).subscribe(() => {
      this.actualizarStockArticulos();
      this.consultarPedidos();
      this.mostrarFormularioNuevoPedido = false;
      this.nuevoPedido = { articulos: [] };
    });
  }

  agregarArticulo() {
    if (this.articuloSeleccionado && this.cantidad > 0 && this.cantidad <= this.articuloSeleccionado.stock) {
      const articuloPedido = {
        ...this.articuloSeleccionado,
        cantidad: this.cantidad,
        precioTotal: this.articuloSeleccionado.precio * this.cantidad
      };
      this.nuevoPedido.articulos.push(articuloPedido);
      this.articuloSeleccionado = null;
      this.cantidad = 0;
    }
  }

  actualizarStockArticulos() {
    this.nuevoPedido.articulos.forEach((articuloPedido: any) => {
      const articulo = this.articulos.find(a => a.id === articuloPedido.id);
      if (articulo) {
        articulo.stock -= articuloPedido.cantidad;
        this.articuloService.updateArticulo(articulo).subscribe();
      }
    });
  }

  mostrarNuevoPedido() {
    this.mostrarFormularioNuevoPedido = true;
  }

  ocultarNuevoPedido() {
    this.mostrarFormularioNuevoPedido = false;
  }

  eliminarPedido(id: string) {
    this.pedidoService.deletePedido(id).subscribe(() => this.consultarPedidos());
  }

  actualizarPedido(pedido: any) {
    this.pedidoService.updatePedido(pedido).subscribe(() => this.consultarPedidos());
  }
}

