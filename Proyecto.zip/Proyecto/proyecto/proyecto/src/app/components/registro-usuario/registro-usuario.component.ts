import { Component } from '@angular/core';
import { UserService } from '../../shared/services/user-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-registro-usuario',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './registro-usuario.component.html',
  styleUrl: './registro-usuario.component.scss'
})
export class RegistroComponent {
  nuevoUsuarioNombre: string = '';
  nuevoUsuarioContrasena: string = '';

  constructor(private usuarioService: UserService) {}

  registrarUsuario() {
    if (this.nuevoUsuarioNombre.trim() && this.nuevoUsuarioContrasena.trim()) {
      const nuevoUsuario = {
        nombre: this.nuevoUsuarioNombre,
        contrasena: this.nuevoUsuarioContrasena,
        rol: 'user',
        pedidos: [],
        topArticulos: []
      };
      this.usuarioService.addUsuario(nuevoUsuario).subscribe(() => {
        alert('Usuario registrado exitosamente');
        this.nuevoUsuarioNombre = '';
        this.nuevoUsuarioContrasena = '';
      });
    }
  }
}
