import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ArticulosComponent } from './components/articulos/articulos.component';
import { PedidosComponent } from './components/pedidos/pedidos.component';
import { NgModule } from '@angular/core';
import { LoginComponent } from './components/login/login.component';
import { RegistroComponent } from './components/registro-usuario/registro-usuario.component';
import { UsuariosComponent } from './components/usuarios/usuarios.component';


export const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'registro', component: RegistroComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'usuarios', component: UsuariosComponent },
  { path: 'articulos', component: ArticulosComponent },
  { path: 'pedidos', component: PedidosComponent }
];



@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]

})

export class AppRoutingModule {}
