import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UsuarioSeleccionadoService {
  private usuario: any = null;

  setUsuario(usuario: any) {
    this.usuario = usuario;
    localStorage.setItem('usuario', JSON.stringify(usuario));
  }

  getUsuario() {
    if (this.usuario === null) {
      const usuarioStr = localStorage.getItem('usuario');
      if (usuarioStr) {
        this.usuario = JSON.parse(usuarioStr);
      }
    }
    return this.usuario;
  }

  clearUsuario() {
    this.usuario = null;
    localStorage.removeItem('usuario');
  }
}
