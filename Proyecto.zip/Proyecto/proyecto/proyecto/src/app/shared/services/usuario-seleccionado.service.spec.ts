import { TestBed } from '@angular/core/testing';

import { UsuarioSeleccionadoService } from './usuario-seleccionado.service';

describe('UsuarioSeleccionadoService', () => {
  let service: UsuarioSeleccionadoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UsuarioSeleccionadoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
