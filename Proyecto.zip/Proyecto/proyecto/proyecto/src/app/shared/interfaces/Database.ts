import { Articulo } from './Articulo';
import { Pedido } from './Pedido';
import { Usuario } from './Usuario';

export interface Database {
  ARTICULOS: Articulo[];
  PEDIDOS: Pedido[];
  USUARIOS: Usuario[];
}