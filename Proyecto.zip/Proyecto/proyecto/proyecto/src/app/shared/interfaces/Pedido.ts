import { PedidoArticulo } from './PedidoArticulo';

export interface Pedido {
  id: number;
  fecha: string;
  nombre: string;
  usuarioId: number;
  articulos: PedidoArticulo[];
}