export interface PedidoArticulo {
    articuloId: number;
    cantidad: number;
  }