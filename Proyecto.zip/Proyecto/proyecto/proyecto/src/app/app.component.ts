import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router, RouterModule, RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { UsuarioSeleccionadoService } from './shared/services/usuario-seleccionado.service';
import { PedidosServiceService } from './shared/services/pedidos-service.service';
import { ArticulosServiceService } from './shared/services/articulos-service.service';
import { UserService } from './shared/services/user-service.service';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  imports: [RouterModule, CommonModule, FormsModule]
})
export class AppComponent implements OnInit {
  [x: string]: any;
  usuariosCount: number = 0;
  articulosCount: number = 0;
  pedidosCount: number = 0;
  usuarioLogueado: any = null;

  constructor(
    private usuarioService: UserService,
    private articuloService: ArticulosServiceService,
    private pedidoService: PedidosServiceService,
    private usuarioSeleccionadoService: UsuarioSeleccionadoService,
    private router: Router
  ) {}

  ngOnInit() {
    this.getCounts();
    this.usuarioLogueado = this.usuarioSeleccionadoService.getUsuario();
  }

  getCounts() {
    this.usuarioService.getUsuarios().subscribe(data => this.usuariosCount = data.length);
    this.articuloService.getArticulos().subscribe(data => this.articulosCount = data.length);
    this.pedidoService.getPedidos().subscribe(data => this.pedidosCount = data.length);
  }

  logout() {
    this.usuarioSeleccionadoService.clearUsuario();
    this.router.navigate(['/login']);
  }
}
